package Model;

/**
 * Created by Rajesh Dabhi on 27/6/2017.
 */

public class Socity_model {

    String socity_id;
    String socity_name;
    String s_pincode;

    String delivery_charge;

    public String getSocity_id(){
        return socity_id;
    }

    public String getSocity_name(){
        return socity_name;
    }

    public String getS_pincode() {
        return s_pincode;
    }

    public String getDelivery_charge(){
        return delivery_charge;
    }

}
